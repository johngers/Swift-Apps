import UIKit

/// Hosts a text field for the user to enter a question
class AskCell: UITableViewCell {

    @IBOutlet weak var textField: UITextField!

}
